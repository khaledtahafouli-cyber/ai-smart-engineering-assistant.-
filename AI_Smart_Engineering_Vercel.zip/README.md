# AI Smart Engineering Assistant — Vercel Edition

A responsive, static dashboard for exploring synthetic industrial sensor data. Designed to deploy easily on Vercel.

## Deploy using GitHub + Vercel (phone-friendly)

1. Download and unzip `AI_Smart_Engineering_Vercel.zip`.
2. Open GitHub and create a **new repository** named `ai-smart-engineering-assistant`. Public or private is your choice.
3. In the new repository, choose **Add file → Upload files** and upload `index.html` from the unzipped folder. Also upload this `README.md` if desired. Commit the files to the repository's default branch.
4. Open Vercel and sign in with GitHub.
5. Choose **Add New → Project**, import `ai-smart-engineering-assistant`.
6. For a plain static HTML project, leave Framework Preset as **Other**. No Build Command is required; if Vercel asks for an Output Directory, use `.` (root). Deploy.
7. Wait for the deployment to finish, then open the `.vercel.app` URL Vercel gives you.

## What this edition does
- Responsive engineering dashboard.
- Interactive temperature, vibration, RPM, and pressure controls.
- Synthetic sensor scatter plot and sample table.
- CSV export.

## Important technical note
This Vercel edition is a static browser demo. The interactive classification is an illustrative threshold-based score, not a trained model. The accompanying Python/Streamlit project demonstrates a Random Forest workflow on synthetic data and is better hosted on a Python-friendly platform (such as Streamlit Community Cloud). Do not present synthetic demo performance as real industrial validation.
